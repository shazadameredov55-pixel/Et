"""
Product blueprints: one per supported niche (config/categories.yaml
subcategory ids). A blueprint defines *structural* differences between
products — which sheets exist, what each sheet computes, which features
are present — so that variation between products comes from Target
Customer -> Problem -> UX -> Layout, not from swapping colors.

XlsxGenerator and PdfGenerator consume blueprints; they never hardcode
niche-specific logic themselves.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ColumnSpec:
    header: str
    width: float
    number_format: Optional[str] = None   # e.g. "#,##0.00", "mm/dd/yyyy", "0.0%"
    data_validation: Optional[dict] = None  # {"type": "list", "formula1": '"Rent,Groceries,..."'}


@dataclass
class SheetSpec:
    sheet_key: str            # e.g. "dashboard", "income", "expenses"
    title: str
    columns: list[ColumnSpec]
    starting_data_row: int = 2
    sample_rows: int = 6      # how many demo rows to seed (cleared/marked DEMO before packaging)
    freeze_panes: str = "A2"
    has_totals_row: bool = True
    conditional_formatting: list[str] = field(default_factory=list)  # rule ids, resolved by generator
    notes: str = ""


@dataclass
class ProductBlueprint:
    niche: str
    display_name: str
    sheets: list[SheetSpec]
    core_formulas: list[str]           # human-readable description, actual formulas built in generator
    default_target_customer: str
    default_features: list[str]
    seo_title_suffix: str = ""         # appended to product_spec.title for a keyword-rich Etsy title
    seo_keywords: list[str] = field(default_factory=list)  # up to 13 tags, each ≤20 chars (Etsy's limits)


# --------------------------------------------------------------------------
# Blueprint registry
# --------------------------------------------------------------------------

def _monthly_budget_tracker() -> ProductBlueprint:
    return ProductBlueprint(
        niche="monthly_budget_tracker",
        display_name="Monthly Budget Tracker",
        default_target_customer="student_or_budget_beginner",
        default_features=[
            "monthly income vs expense summary",
            "category breakdown with percentages",
            "remaining balance calculation",
            "dropdown category selection",
        ],
        seo_title_suffix="Monthly Budget Planner Excel Spreadsheet Digital Download for Personal Finance",
        seo_keywords=[
            "budget tracker", "monthly budget", "budget planner", "budget spreadsheet",
            "finance tracker", "money tracker", "excel budget", "budget template",
            "expense tracker", "personal finance", "saving tracker", "financial planner",
            "digital download",
        ],
        core_formulas=[
            "Remaining = Income - Expenses",
            "Category % = Category Total / Total Expenses",
        ],
        sheets=[
            SheetSpec(
                sheet_key="dashboard",
                title="Dashboard",
                columns=[
                    ColumnSpec("Metric", 28),
                    ColumnSpec("Value", 16, number_format="#,##0.00"),
                ],
                sample_rows=0,
                has_totals_row=False,
                notes="Summary pulled via formulas from Income/Expenses sheets.",
            ),
            SheetSpec(
                sheet_key="income",
                title="Income",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("Source", 22),
                    ColumnSpec("Amount", 14, number_format="#,##0.00"),
                ],
                sample_rows=4,
                conditional_formatting=["highlight_negative"],
            ),
            SheetSpec(
                sheet_key="expenses",
                title="Expenses",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec(
                        "Category", 20,
                        data_validation={
                            "type": "list",
                            "formula1": '"Housing,Food,Transport,Utilities,Entertainment,Other"',
                        },
                    ),
                    ColumnSpec("Description", 26),
                    ColumnSpec("Amount", 14, number_format="#,##0.00"),
                ],
                sample_rows=8,
                conditional_formatting=["highlight_over_budget"],
            ),
            SheetSpec(
                sheet_key="instructions",
                title="Instructions",
                columns=[ColumnSpec("Instructions", 90)],
                sample_rows=0,
                has_totals_row=False,
                freeze_panes="A1",
            ),
        ],
    )


def _freelancer_finance_tracker() -> ProductBlueprint:
    return ProductBlueprint(
        niche="freelancer_finance_tracker",
        display_name="Freelancer Finance Tracker",
        default_target_customer="freelancer_or_independent_contractor",
        default_features=[
            "per-client income tracking",
            "quarterly estimated tax set-aside calculator",
            "business expense log with deductible flag",
            "invoice status tracker",
            "quarterly + annual summary dashboard",
        ],
        seo_title_suffix="Excel Spreadsheet for Self Employed Income Expense and Quarterly Tax Tracking",
        seo_keywords=[
            "freelancer tracker", "finance spreadsheet", "income tracker", "expense tracker",
            "tax spreadsheet", "invoice tracker", "self employed", "small business",
            "excel template", "budget spreadsheet", "freelance finance", "quarterly taxes",
            "digital download",
        ],
        core_formulas=[
            "Net Income = Gross Income - Business Expenses",
            "Tax Set-Aside = Net Income * Tax Rate (editable)",
            "Outstanding = SUMIF(Invoice Status = 'Unpaid')",
        ],
        sheets=[
            SheetSpec(
                sheet_key="dashboard",
                title="Dashboard",
                columns=[
                    ColumnSpec("Metric", 30),
                    ColumnSpec("Q1", 14, number_format="#,##0.00"),
                    ColumnSpec("Q2", 14, number_format="#,##0.00"),
                    ColumnSpec("Q3", 14, number_format="#,##0.00"),
                    ColumnSpec("Q4", 14, number_format="#,##0.00"),
                    ColumnSpec("Annual", 14, number_format="#,##0.00"),
                ],
                sample_rows=0,
                has_totals_row=False,
            ),
            SheetSpec(
                sheet_key="client_income",
                title="Client Income",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("Client", 22),
                    ColumnSpec(
                        "Invoice Status", 16,
                        data_validation={"type": "list", "formula1": '"Paid,Unpaid,Overdue"'},
                    ),
                    ColumnSpec("Amount", 14, number_format="#,##0.00"),
                ],
                sample_rows=6,
                conditional_formatting=["highlight_overdue"],
            ),
            SheetSpec(
                sheet_key="business_expenses",
                title="Business Expenses",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec(
                        "Category", 20,
                        data_validation={
                            "type": "list",
                            "formula1": '"Software,Equipment,Travel,Marketing,Office,Other"',
                        },
                    ),
                    ColumnSpec(
                        "Deductible", 12,
                        data_validation={"type": "list", "formula1": '"Yes,No"'},
                    ),
                    ColumnSpec("Amount", 14, number_format="#,##0.00"),
                ],
                sample_rows=6,
            ),
            SheetSpec(
                sheet_key="tax_setaside",
                title="Tax Set-Aside",
                columns=[
                    ColumnSpec("Quarter", 14),
                    ColumnSpec("Net Income", 16, number_format="#,##0.00"),
                    ColumnSpec("Tax Rate", 12, number_format="0.0%"),
                    ColumnSpec("Set-Aside Amount", 18, number_format="#,##0.00"),
                ],
                sample_rows=4,
                has_totals_row=True,
            ),
            SheetSpec(
                sheet_key="instructions",
                title="Instructions",
                columns=[ColumnSpec("Instructions", 90)],
                sample_rows=0,
                has_totals_row=False,
                freeze_panes="A1",
            ),
        ],
    )


def _debt_payoff_tracker() -> ProductBlueprint:
    return ProductBlueprint(
        niche="debt_payoff_tracker",
        display_name="Debt Payoff Tracker",
        default_target_customer="individual_paying_down_debt",
        default_features=[
            "multi-debt balance tracker",
            "snowball vs avalanche payoff order",
            "monthly payment log per debt",
            "payoff progress percentage",
        ],
        seo_title_suffix="Debt Snowball and Avalanche Excel Spreadsheet Digital Download Payoff Planner",
        seo_keywords=[
            "debt payoff tracker", "debt tracker", "debt snowball", "debt free journey",
            "payoff planner", "finance spreadsheet", "budget tracker", "excel template",
            "debt payoff plan", "money management", "debt avalanche", "financial planner",
            "digital download",
        ],
        core_formulas=[
            "Remaining Balance = Starting Balance - SUM(Payments)",
            "Progress % = 1 - (Remaining Balance / Starting Balance)",
        ],
        sheets=[
            SheetSpec(
                sheet_key="dashboard",
                title="Dashboard",
                columns=[
                    ColumnSpec("Debt", 22),
                    ColumnSpec("Starting Balance", 16, number_format="#,##0.00"),
                    ColumnSpec("Remaining Balance", 16, number_format="#,##0.00"),
                    ColumnSpec("Progress %", 12, number_format="0.0%"),
                ],
                sample_rows=0,
                has_totals_row=False,
                conditional_formatting=["progress_bar"],
            ),
            SheetSpec(
                sheet_key="debts",
                title="Debts",
                columns=[
                    ColumnSpec("Debt Name", 22),
                    ColumnSpec(
                        "Type", 16,
                        data_validation={
                            "type": "list",
                            "formula1": '"Credit Card,Student Loan,Auto Loan,Personal Loan,Other"',
                        },
                    ),
                    ColumnSpec("Starting Balance", 16, number_format="#,##0.00"),
                    ColumnSpec("Interest Rate", 12, number_format="0.0%"),
                    ColumnSpec("Min Payment", 14, number_format="#,##0.00"),
                ],
                sample_rows=4,
                has_totals_row=False,
            ),
            SheetSpec(
                sheet_key="payment_log",
                title="Payment Log",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("Debt Name", 22),
                    ColumnSpec("Payment Amount", 16, number_format="#,##0.00"),
                ],
                sample_rows=6,
            ),
            SheetSpec(
                sheet_key="instructions",
                title="Instructions",
                columns=[ColumnSpec("Instructions", 90)],
                sample_rows=0,
                has_totals_row=False,
                freeze_panes="A1",
            ),
        ],
    )


def _small_business_inventory_tracker() -> ProductBlueprint:
    return ProductBlueprint(
        niche="small_business_inventory_tracker",
        display_name="Small Business Inventory & Stock Tracker",
        default_target_customer="small_business_owner_or_reseller",
        default_features=[
            "SKU-level inventory with cost, retail price and live margin",
            "automatic low-stock flag against a per-item reorder point",
            "stock in / stock out movement log (materials + finished goods)",
            "supplier directory with lead time",
            "dashboard: total inventory value, low-stock count, top movers",
        ],
        seo_title_suffix="Small Business Inventory Tracker Excel Spreadsheet Stock Control Digital Download",
        seo_keywords=[
            "inventory tracker", "stock tracker", "inventory spreadsheet", "stock control",
            "small business", "inventory management", "reseller inventory", "excel inventory",
            "stock in stock out", "inventory excel", "reorder point", "product inventory",
            "digital download",
        ],
        core_formulas=[
            "On Hand = Opening Qty + SUM(Stock In) - SUM(Stock Out)",
            "Low Stock = On Hand <= Reorder Point",
            "Inventory Value = SUM(On Hand * Unit Cost)",
            "Margin % = (Retail Price - Unit Cost) / Retail Price",
        ],
        sheets=[
            SheetSpec(
                sheet_key="dashboard",
                title="Dashboard",
                columns=[
                    ColumnSpec("Metric", 30),
                    ColumnSpec("Value", 16, number_format="#,##0.00"),
                ],
                sample_rows=0,
                has_totals_row=False,
                notes="Pulled via formulas from Inventory/Stock In/Stock Out.",
            ),
            SheetSpec(
                sheet_key="inventory",
                title="Inventory",
                columns=[
                    ColumnSpec("SKU", 14),
                    ColumnSpec("Item Name", 24),
                    ColumnSpec(
                        "Category", 16,
                        data_validation={
                            "type": "list",
                            "formula1": '"Raw Material,Finished Good,Packaging,Other"',
                        },
                    ),
                    ColumnSpec("Unit Cost", 12, number_format="#,##0.00"),
                    ColumnSpec("Retail Price", 12, number_format="#,##0.00"),
                    ColumnSpec("On Hand", 10, number_format="#,##0"),
                    ColumnSpec("Reorder Point", 12, number_format="#,##0"),
                    ColumnSpec("Margin %", 10, number_format="0.0%"),
                ],
                sample_rows=6,
                conditional_formatting=["highlight_low_stock"],
            ),
            SheetSpec(
                sheet_key="stock_in",
                title="Stock In",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("SKU", 14),
                    ColumnSpec("Supplier", 20),
                    ColumnSpec("Qty In", 10, number_format="#,##0"),
                    ColumnSpec("Unit Cost", 12, number_format="#,##0.00"),
                ],
                sample_rows=5,
            ),
            SheetSpec(
                sheet_key="stock_out",
                title="Stock Out",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("SKU", 14),
                    ColumnSpec(
                        "Reason", 16,
                        data_validation={
                            "type": "list",
                            "formula1": '"Sale,Used in Production,Damaged,Return,Other"',
                        },
                    ),
                    ColumnSpec("Qty Out", 10, number_format="#,##0"),
                ],
                sample_rows=5,
            ),
            SheetSpec(
                sheet_key="suppliers",
                title="Suppliers",
                columns=[
                    ColumnSpec("Supplier", 22),
                    ColumnSpec("Contact", 24),
                    ColumnSpec("Lead Time (days)", 16, number_format="#,##0"),
                    ColumnSpec("Notes", 30),
                ],
                sample_rows=3,
                has_totals_row=False,
            ),
            SheetSpec(
                sheet_key="instructions",
                title="Instructions",
                columns=[ColumnSpec("Instructions", 90)],
                sample_rows=0,
                has_totals_row=False,
                freeze_panes="A1",
            ),
        ],
    )


def _warehouse_stock_movement_tracker() -> ProductBlueprint:
    return ProductBlueprint(
        niche="warehouse_stock_movement_tracker",
        display_name="Warehouse Stock In-Out & Location Tracker",
        default_target_customer="warehouse_or_multi_location_operator",
        default_features=[
            "item master with bin/location and reorder point",
            "separate stock-in and stock-out logs with running balance",
            "inter-location stock transfer log",
            "dashboard: items below reorder point, total units on hand by location",
        ],
        seo_title_suffix="Warehouse Inventory Stock In Out Log Excel Spreadsheet Digital Download",
        seo_keywords=[
            "warehouse inventory", "stock in out", "inventory log", "stock movement",
            "warehouse tracker", "inventory excel", "stock control sheet", "location tracker",
            "reorder point", "inventory spreadsheet", "stock transfer", "excel template",
            "digital download",
        ],
        core_formulas=[
            "Balance = Opening + SUM(Stock In) - SUM(Stock Out) +/- Transfers",
            "Below Reorder = Balance <= Reorder Point",
        ],
        sheets=[
            SheetSpec(
                sheet_key="dashboard",
                title="Dashboard",
                columns=[
                    ColumnSpec("Metric", 30),
                    ColumnSpec("Value", 16, number_format="#,##0.00"),
                ],
                sample_rows=0,
                has_totals_row=False,
            ),
            SheetSpec(
                sheet_key="item_master",
                title="Item Master",
                columns=[
                    ColumnSpec("SKU", 14),
                    ColumnSpec("Item Name", 24),
                    ColumnSpec("Location / Bin", 16),
                    ColumnSpec("Unit", 10),
                    ColumnSpec("On Hand", 10, number_format="#,##0"),
                    ColumnSpec("Reorder Point", 12, number_format="#,##0"),
                ],
                sample_rows=6,
                conditional_formatting=["highlight_low_stock"],
            ),
            SheetSpec(
                sheet_key="stock_in",
                title="Stock In",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("SKU", 14),
                    ColumnSpec("Received From", 20),
                    ColumnSpec("Qty In", 10, number_format="#,##0"),
                ],
                sample_rows=5,
            ),
            SheetSpec(
                sheet_key="stock_out",
                title="Stock Out",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("SKU", 14),
                    ColumnSpec("Sent To / Reason", 20),
                    ColumnSpec("Qty Out", 10, number_format="#,##0"),
                ],
                sample_rows=5,
            ),
            SheetSpec(
                sheet_key="transfers",
                title="Location Transfers",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("SKU", 14),
                    ColumnSpec("From Location", 16),
                    ColumnSpec("To Location", 16),
                    ColumnSpec("Qty", 10, number_format="#,##0"),
                ],
                sample_rows=4,
            ),
            SheetSpec(
                sheet_key="instructions",
                title="Instructions",
                columns=[ColumnSpec("Instructions", 90)],
                sample_rows=0,
                has_totals_row=False,
                freeze_panes="A1",
            ),
        ],
    )


def _reseller_profit_inventory_tracker() -> ProductBlueprint:
    return ProductBlueprint(
        niche="reseller_profit_inventory_tracker",
        display_name="Reseller Inventory & Profit Tracker",
        default_target_customer="online_reseller_handmade_seller",
        default_features=[
            "per-listing inventory with cost, list price and platform fees",
            "sales log with automatic net-profit calculation",
            "on-hand quantity tied to sales (auto-decrements)",
            "dashboard: revenue, fees paid, net profit, best sellers",
        ],
        seo_title_suffix="Reseller Inventory and Profit Tracker Excel Spreadsheet for Etsy eBay Depop Sellers",
        seo_keywords=[
            "reseller spreadsheet", "inventory profit tracker", "etsy seller", "ebay inventory",
            "profit tracker", "small business inventory", "sales tracker", "seller spreadsheet",
            "inventory excel", "reseller tool", "fee tracker", "online seller",
            "digital download",
        ],
        core_formulas=[
            "Net Profit = Sale Price - Platform Fees - Unit Cost - Shipping Cost",
            "Margin % = Net Profit / Sale Price",
            "On Hand = Starting Qty - SUM(Units Sold)",
        ],
        sheets=[
            SheetSpec(
                sheet_key="dashboard",
                title="Dashboard",
                columns=[
                    ColumnSpec("Metric", 30),
                    ColumnSpec("Value", 16, number_format="#,##0.00"),
                ],
                sample_rows=0,
                has_totals_row=False,
            ),
            SheetSpec(
                sheet_key="inventory",
                title="Inventory & Listings",
                columns=[
                    ColumnSpec("SKU", 14),
                    ColumnSpec("Item Name", 24),
                    ColumnSpec(
                        "Platform", 14,
                        data_validation={
                            "type": "list",
                            "formula1": '"Etsy,eBay,Depop,Vinted,In Person,Other"',
                        },
                    ),
                    ColumnSpec("Unit Cost", 12, number_format="#,##0.00"),
                    ColumnSpec("List Price", 12, number_format="#,##0.00"),
                    ColumnSpec("Starting Qty", 12, number_format="#,##0"),
                    ColumnSpec("On Hand", 10, number_format="#,##0"),
                ],
                sample_rows=6,
            ),
            SheetSpec(
                sheet_key="sales_log",
                title="Sales Log",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("SKU", 14),
                    ColumnSpec("Sale Price", 12, number_format="#,##0.00"),
                    ColumnSpec("Platform Fees", 12, number_format="#,##0.00"),
                    ColumnSpec("Shipping Cost", 12, number_format="#,##0.00"),
                    ColumnSpec("Net Profit", 12, number_format="#,##0.00"),
                ],
                sample_rows=6,
                conditional_formatting=["highlight_negative"],
            ),
            SheetSpec(
                sheet_key="instructions",
                title="Instructions",
                columns=[ColumnSpec("Instructions", 90)],
                sample_rows=0,
                has_totals_row=False,
                freeze_panes="A1",
            ),
        ],
    )


def _retail_store_inventory_tracker() -> ProductBlueprint:
    return ProductBlueprint(
        niche="retail_store_inventory_tracker",
        display_name="Retail Store Inventory Tracker",
        default_target_customer="retail_store_owner",
        default_features=[
            "barcode/SKU-level inventory with size/variant tracking",
            "cost vs retail margin per item",
            "automatic low-stock flag against a per-item reorder point",
            "stock in / stock out (sale, return, damage) log",
            "dashboard: inventory value, low-stock count, units sold",
        ],
        seo_title_suffix="Retail Store Inventory Tracker Excel Spreadsheet Stock Control Digital Download",
        seo_keywords=[
            "retail inventory", "store inventory tracker", "boutique inventory", "stock tracker",
            "barcode inventory", "inventory spreadsheet", "retail store", "small shop inventory",
            "stock control", "inventory excel", "reorder point", "product inventory",
            "digital download",
        ],
        core_formulas=[
            "On Hand = SUM(Stock In) - SUM(Stock Out)",
            "Low Stock = On Hand <= Reorder Point",
            "Margin % = (Retail Price - Unit Cost) / Retail Price",
        ],
        sheets=[
            SheetSpec(
                sheet_key="dashboard",
                title="Dashboard",
                columns=[ColumnSpec("Metric", 30), ColumnSpec("Value", 16, number_format="#,##0.00")],
                sample_rows=0, has_totals_row=False,
            ),
            SheetSpec(
                sheet_key="inventory",
                title="Inventory",
                columns=[
                    ColumnSpec("SKU / Barcode", 16),
                    ColumnSpec("Item Name", 22),
                    ColumnSpec("Size / Variant", 14),
                    ColumnSpec(
                        "Category", 16,
                        data_validation={"type": "list", "formula1": '"Apparel,Accessories,Home,Beauty,Other"'},
                    ),
                    ColumnSpec("Unit Cost", 12, number_format="#,##0.00"),
                    ColumnSpec("Retail Price", 12, number_format="#,##0.00"),
                    ColumnSpec("On Hand", 10, number_format="#,##0"),
                    ColumnSpec("Reorder Point", 12, number_format="#,##0"),
                    ColumnSpec("Margin %", 10, number_format="0.0%"),
                ],
                sample_rows=6,
                conditional_formatting=["highlight_low_stock"],
            ),
            SheetSpec(
                sheet_key="stock_in",
                title="Stock In",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("SKU / Barcode", 16),
                    ColumnSpec("Supplier", 20),
                    ColumnSpec("Qty In", 10, number_format="#,##0"),
                ],
                sample_rows=5,
            ),
            SheetSpec(
                sheet_key="stock_out",
                title="Stock Out",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("SKU / Barcode", 16),
                    ColumnSpec(
                        "Reason", 16,
                        data_validation={"type": "list", "formula1": '"Sale,Return,Damaged,Other"'},
                    ),
                    ColumnSpec("Qty Out", 10, number_format="#,##0"),
                ],
                sample_rows=5,
            ),
            SheetSpec(
                sheet_key="suppliers",
                title="Suppliers",
                columns=[
                    ColumnSpec("Supplier", 22), ColumnSpec("Contact", 24),
                    ColumnSpec("Lead Time (days)", 16, number_format="#,##0"), ColumnSpec("Notes", 30),
                ],
                sample_rows=3, has_totals_row=False,
            ),
            SheetSpec(
                sheet_key="instructions", title="Instructions",
                columns=[ColumnSpec("Instructions", 90)],
                sample_rows=0, has_totals_row=False, freeze_panes="A1",
            ),
        ],
    )


def _cafe_restaurant_inventory_tracker() -> ProductBlueprint:
    return ProductBlueprint(
        niche="cafe_restaurant_inventory_tracker",
        display_name="Cafe & Restaurant Inventory Tracker",
        default_target_customer="cafe_or_restaurant_owner",
        default_features=[
            "ingredient-level stock with unit (kg/L/pcs) and expiry date",
            "automatic low-stock AND expiring-soon flags",
            "daily usage log tied to menu items",
            "waste log with cost impact",
            "dashboard: low-stock count, expiring-soon count, waste cost",
        ],
        seo_title_suffix="Cafe Restaurant Inventory Tracker Excel Spreadsheet Food Stock Control Digital Download",
        seo_keywords=[
            "restaurant inventory", "cafe inventory tracker", "food inventory", "kitchen inventory",
            "ingredient tracker", "stock control", "food cost tracker", "inventory spreadsheet",
            "expiry tracker", "restaurant excel", "reorder point", "waste log",
            "digital download",
        ],
        core_formulas=[
            "On Hand = Opening + SUM(Received) - SUM(Used) - SUM(Wasted)",
            "Expiring Soon = Expiry Date <= TODAY() + 7",
            "Waste Cost = SUM(Qty Wasted * Unit Cost)",
        ],
        sheets=[
            SheetSpec(
                sheet_key="dashboard",
                title="Dashboard",
                columns=[ColumnSpec("Metric", 30), ColumnSpec("Value", 16, number_format="#,##0.00")],
                sample_rows=0, has_totals_row=False,
            ),
            SheetSpec(
                sheet_key="ingredients",
                title="Ingredients",
                columns=[
                    ColumnSpec("Item", 22),
                    ColumnSpec("Unit", 10),
                    ColumnSpec("Unit Cost", 12, number_format="#,##0.00"),
                    ColumnSpec("On Hand", 10, number_format="#,##0.0"),
                    ColumnSpec("Reorder Point", 12, number_format="#,##0.0"),
                    ColumnSpec("Expiry Date", 14, number_format="mm/dd/yyyy"),
                ],
                sample_rows=6,
                conditional_formatting=["highlight_low_stock", "highlight_expiring_soon"],
            ),
            SheetSpec(
                sheet_key="usage_log",
                title="Usage Log",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("Item", 20),
                    ColumnSpec("Menu Item", 20),
                    ColumnSpec("Qty Used", 12, number_format="#,##0.0"),
                ],
                sample_rows=6,
            ),
            SheetSpec(
                sheet_key="waste_log",
                title="Waste Log",
                columns=[
                    ColumnSpec("Date", 14, number_format="mm/dd/yyyy"),
                    ColumnSpec("Item", 20),
                    ColumnSpec(
                        "Reason", 16,
                        data_validation={"type": "list", "formula1": '"Spoiled,Overprepped,Dropped,Other"'},
                    ),
                    ColumnSpec("Qty Wasted", 12, number_format="#,##0.0"),
                ],
                sample_rows=4,
            ),
            SheetSpec(
                sheet_key="suppliers",
                title="Suppliers",
                columns=[
                    ColumnSpec("Supplier", 22), ColumnSpec("Contact", 24),
                    ColumnSpec("Delivery Days", 18), ColumnSpec("Notes", 30),
                ],
                sample_rows=3, has_totals_row=False,
            ),
            SheetSpec(
                sheet_key="instructions", title="Instructions",
                columns=[ColumnSpec("Instructions", 90)],
                sample_rows=0, has_totals_row=False, freeze_panes="A1",
            ),
        ],
    )


_REGISTRY: dict[str, ProductBlueprint] = {
    "monthly_budget_tracker": _monthly_budget_tracker(),
    "freelancer_finance_tracker": _freelancer_finance_tracker(),
    "debt_payoff_tracker": _debt_payoff_tracker(),
    "small_business_inventory_tracker": _small_business_inventory_tracker(),
    "warehouse_stock_movement_tracker": _warehouse_stock_movement_tracker(),
    "reseller_profit_inventory_tracker": _reseller_profit_inventory_tracker(),
    "retail_store_inventory_tracker": _retail_store_inventory_tracker(),
    "cafe_restaurant_inventory_tracker": _cafe_restaurant_inventory_tracker(),
}


def get_blueprint(niche: str) -> ProductBlueprint:
    if niche not in _REGISTRY:
        raise KeyError(
            f"No blueprint registered for niche '{niche}'. "
            f"Available: {sorted(_REGISTRY.keys())}. "
            f"Add a new _<niche>() function and register it to support more niches."
        )
    return _REGISTRY[niche]


def available_niches() -> list[str]:
    return sorted(_REGISTRY.keys())
