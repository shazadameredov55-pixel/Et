"""
XLSX product generator. Implements src.core.interfaces.ProductGenerator.

Consumes a (ProductSpec, DesignProfile) pair plus the ProductBlueprint
resolved from ProductSpec.niche, and produces a real, working Excel
workbook: live formulas (not baked-in values), number formats, data
validation dropdowns, freeze panes, conditional formatting, and named
ranges the formulas rely on.

Demo/sample rows are seeded ONLY to prove the formulas compute correctly
(see _seed_sample_data + tests/test_financial_formulas.py), then either
removed or clearly marked "DEMO" before the file is considered final —
controlled by `clear_demo_data`.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from openpyxl import Workbook
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.formatting.rule import CellIsRule, FormulaRule, ColorScaleRule
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter

from src.core.interfaces import ProductGenerator, GenerationResult, GeneratedFile
from src.core.models import ProductSpec, DesignProfile
from src.generators.blueprints import get_blueprint, ProductBlueprint, SheetSpec

logger = logging.getLogger(__name__)


class XlsxIntegrityError(Exception):
    """Raised when a generated workbook fails a basic integrity check
    (e.g. cannot be reopened, missing an expected sheet)."""


class XlsxGenerator(ProductGenerator):
    output_type = "xlsx"

    def __init__(self, clear_demo_data: bool = True):
        # clear_demo_data=False is used internally by the "financial
        # testing" step (madde 8): seed sample data, verify computed
        # values, THEN generate the real, clean file with it True.
        self.clear_demo_data = clear_demo_data

    # ------------------------------------------------------------------
    # Public entrypoint (ProductGenerator contract)
    # ------------------------------------------------------------------

    def generate(self, product_spec: ProductSpec, design_profile: DesignProfile, output_dir: str) -> GenerationResult:
        try:
            blueprint = get_blueprint(product_spec.niche)
        except KeyError as e:
            logger.error("XLSX generation failed: %s", e)
            return GenerationResult(success=False, files=[], error=str(e))

        try:
            wb = Workbook()
            # Remove the default sheet openpyxl creates; we add our own in order.
            default_sheet = wb.active
            wb.remove(default_sheet)

            style = _StyleKit(design_profile)

            sheet_objs: dict[str, Worksheet] = {}
            for sheet_spec in blueprint.sheets:
                ws = wb.create_sheet(title=sheet_spec.title[:31])  # Excel sheet name limit
                sheet_objs[sheet_spec.sheet_key] = ws
                self._build_sheet(ws, sheet_spec, style)

            self._seed_sample_data(sheet_objs, blueprint)
            self._apply_formulas(sheet_objs, blueprint, product_spec)
            self._write_instructions(sheet_objs.get("instructions"), product_spec, blueprint, style)

            if self.clear_demo_data:
                self._clear_demo_rows(sheet_objs, blueprint)

            os.makedirs(output_dir, exist_ok=True)
            file_path = os.path.join(output_dir, "product.xlsx")
            wb.save(file_path)

        except Exception as e:  # noqa: BLE001 - must not raise past this boundary
            logger.exception("XLSX generation raised an unexpected error")
            return GenerationResult(success=False, files=[], error=str(e))

        try:
            self._verify_integrity(file_path, blueprint)
        except XlsxIntegrityError as e:
            logger.error("XLSX integrity check failed: %s", e)
            return GenerationResult(success=False, files=[], error=str(e))

        return GenerationResult(
            success=True,
            files=[
                GeneratedFile(
                    file_path=file_path,
                    file_type="xlsx",
                    description=f"{blueprint.display_name} workbook",
                )
            ],
        )

    # ------------------------------------------------------------------
    # Sheet construction
    # ------------------------------------------------------------------

    def _build_sheet(self, ws: Worksheet, spec: SheetSpec, style: "_StyleKit") -> None:
        # Header row
        for col_idx, col in enumerate(spec.columns, start=1):
            cell = ws.cell(row=1, column=col_idx, value=col.header)
            cell.font = style.header_font
            cell.fill = style.header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = style.thin_border
            ws.column_dimensions[get_column_letter(col_idx)].width = col.width

        ws.row_dimensions[1].height = max(20, style.row_height)
        ws.freeze_panes = spec.freeze_panes

        # Number formats + data validation applied down a reasonable
        # working range (sample rows + headroom for the user to add more).
        working_rows = max(spec.sample_rows, 6) + 44  # generous headroom, still bounded
        for col_idx, col in enumerate(spec.columns, start=1):
            col_letter = get_column_letter(col_idx)
            if col.number_format:
                for row in range(spec.starting_data_row, spec.starting_data_row + working_rows):
                    ws.cell(row=row, column=col_idx).number_format = col.number_format
            if col.data_validation:
                dv = DataValidation(
                    type=col.data_validation["type"],
                    formula1=col.data_validation["formula1"],
                    allow_blank=True,
                    showDropDown=False,  # False = show the dropdown arrow (openpyxl quirk)
                )
                dv.error = "Please choose a value from the list."
                dv.errorTitle = "Invalid entry"
                rng = f"{col_letter}{spec.starting_data_row}:{col_letter}{spec.starting_data_row + working_rows}"
                dv.add(rng)
                ws.add_data_validation(dv)

        if spec.has_totals_row:
            total_row = spec.starting_data_row + working_rows + 1
            label_cell = ws.cell(row=total_row, column=1, value="Total")
            label_cell.font = Font(bold=True)
            for col_idx, col in enumerate(spec.columns, start=1):
                if col.number_format and col_idx > 1:
                    col_letter = get_column_letter(col_idx)
                    first = spec.starting_data_row
                    last = spec.starting_data_row + working_rows - 1
                    total_cell = ws.cell(
                        row=total_row, column=col_idx,
                        value=f"=SUM({col_letter}{first}:{col_letter}{last})",
                    )
                    total_cell.number_format = col.number_format
                    total_cell.font = Font(bold=True)

        for rule_id in spec.conditional_formatting:
            self._apply_conditional_formatting(ws, spec, rule_id, working_rows)

    def _apply_conditional_formatting(self, ws: Worksheet, spec: SheetSpec, rule_id: str, working_rows: int) -> None:
        first = spec.starting_data_row
        last = spec.starting_data_row + working_rows - 1

        red_fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
        green_fill = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")

        # Find the "Amount"-like column for value-based rules.
        amount_col_idx = next(
            (i for i, c in enumerate(spec.columns, start=1) if "Amount" in c.header or "Balance" in c.header),
            None,
        )

        if rule_id == "highlight_negative" and amount_col_idx:
            col_letter = get_column_letter(amount_col_idx)
            rng = f"{col_letter}{first}:{col_letter}{last}"
            ws.conditional_formatting.add(
                rng, CellIsRule(operator="lessThan", formula=["0"], fill=red_fill)
            )
        elif rule_id == "highlight_over_budget" and amount_col_idx:
            col_letter = get_column_letter(amount_col_idx)
            rng = f"{col_letter}{first}:{col_letter}{last}"
            ws.conditional_formatting.add(
                rng, CellIsRule(operator="greaterThan", formula=["500"], fill=red_fill)
            )
        elif rule_id == "highlight_overdue":
            status_col_idx = next((i for i, c in enumerate(spec.columns) if "Status" in spec.columns[i].header), None)
            if status_col_idx:
                col_letter = get_column_letter(status_col_idx + 1)
                rng = f"{col_letter}{first}:{col_letter}{last}"
                ws.conditional_formatting.add(
                    rng, FormulaRule(formula=[f'{col_letter}{first}="Overdue"'], fill=red_fill)
                )
        elif rule_id == "highlight_low_stock":
            on_hand_idx = next((i for i, c in enumerate(spec.columns, start=1) if c.header == "On Hand"), None)
            reorder_idx = next((i for i, c in enumerate(spec.columns, start=1) if "Reorder" in c.header), None)
            if on_hand_idx and reorder_idx:
                on_hand_letter = get_column_letter(on_hand_idx)
                reorder_letter = get_column_letter(reorder_idx)
                rng = f"{on_hand_letter}{first}:{on_hand_letter}{last}"
                ws.conditional_formatting.add(
                    rng,
                    FormulaRule(
                        formula=[f"{on_hand_letter}{first}<={reorder_letter}{first}"],
                        fill=red_fill,
                    ),
                )
        elif rule_id == "highlight_expiring_soon":
            expiry_idx = next((i for i, c in enumerate(spec.columns, start=1) if "Expiry" in c.header), None)
            if expiry_idx:
                col_letter = get_column_letter(expiry_idx)
                rng = f"{col_letter}{first}:{col_letter}{last}"
                yellow_fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
                ws.conditional_formatting.add(
                    rng,
                    FormulaRule(
                        formula=[f"AND({col_letter}{first}<>\"\",{col_letter}{first}<=TODAY()+7)"],
                        fill=yellow_fill,
                    ),
                )
        elif rule_id == "progress_bar":
            pct_col_idx = next((i for i, c in enumerate(spec.columns, start=1) if "%" in c.header), None)
            if pct_col_idx:
                col_letter = get_column_letter(pct_col_idx)
                rng = f"{col_letter}2:{col_letter}20"
                ws.conditional_formatting.add(
                    rng,
                    ColorScaleRule(
                        start_type="min", start_color="FCA5A5",
                        end_type="max", end_color="86EFAC",
                    ),
                )

    # ------------------------------------------------------------------
    # Sample data (for financial verification), formulas, cleanup
    # ------------------------------------------------------------------

    def _seed_sample_data(self, sheets: dict[str, Worksheet], blueprint: ProductBlueprint) -> None:
        """Seed deterministic demo rows. Values chosen so downstream
        formula tests have a known-correct expected result (see
        tests/test_financial_formulas.py)."""
        if "income" in sheets:
            ws = sheets["income"]
            demo = [("2026-01-01", "Salary", 3500.00), ("2026-01-15", "Freelance", 1500.00)]
            for i, (date, source, amount) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=date)
                ws.cell(row=i, column=2, value=f"DEMO: {source}")
                ws.cell(row=i, column=3, value=amount)

        if "expenses" in sheets:
            ws = sheets["expenses"]
            demo = [
                ("2026-01-02", "Housing", "DEMO: Rent", 1800.00),
                ("2026-01-05", "Food", "DEMO: Groceries", 700.00),
                ("2026-01-10", "Transport", "DEMO: Gas", 500.00),
            ]
            for i, (date, cat, desc, amount) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=date)
                ws.cell(row=i, column=2, value=cat)
                ws.cell(row=i, column=3, value=desc)
                ws.cell(row=i, column=4, value=amount)

        if "client_income" in sheets:
            ws = sheets["client_income"]
            demo = [
                ("2026-01-05", "DEMO: Client A", "Paid", 2000.00),
                ("2026-01-20", "DEMO: Client B", "Unpaid", 1200.00),
            ]
            for i, (date, client, status, amount) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=date)
                ws.cell(row=i, column=2, value=client)
                ws.cell(row=i, column=3, value=status)
                ws.cell(row=i, column=4, value=amount)

        if "debts" in sheets:
            ws = sheets["debts"]
            demo = [("DEMO: Credit Card A", "Credit Card", 2000.00, 0.199, 50.00)]
            for i, (name, dtype, bal, rate, minp) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=name)
                ws.cell(row=i, column=2, value=dtype)
                ws.cell(row=i, column=3, value=bal)
                ws.cell(row=i, column=4, value=rate)
                ws.cell(row=i, column=5, value=minp)

        if "payment_log" in sheets:
            ws = sheets["payment_log"]
            demo = [("2026-01-10", "DEMO: Credit Card A", 500.00)]
            for i, (date, name, amount) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=date)
                ws.cell(row=i, column=2, value=name)
                ws.cell(row=i, column=3, value=amount)

        # small_business_inventory_tracker + warehouse_stock_movement_tracker
        # share the same "inventory" / "item_master" + stock_in/out shape.
        if "inventory" in sheets and blueprint.niche == "small_business_inventory_tracker":
            ws = sheets["inventory"]
            demo = [
                ("SKU001", "DEMO: Ceramic Mug", "Finished Good", 4.50, 14.00, 22, 8),
                ("SKU002", "DEMO: Raw Clay (kg)", "Raw Material", 2.00, 0, 40, 15),
            ]
            for i, (sku, name, cat, cost, price, onhand, reorder) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=sku)
                ws.cell(row=i, column=2, value=name)
                ws.cell(row=i, column=3, value=cat)
                ws.cell(row=i, column=4, value=cost)
                ws.cell(row=i, column=5, value=price)
                ws.cell(row=i, column=6, value=onhand)
                ws.cell(row=i, column=7, value=reorder)

        if "stock_in" in sheets and blueprint.niche in (
            "small_business_inventory_tracker", "warehouse_stock_movement_tracker",
            "retail_store_inventory_tracker",
        ):
            ws = sheets["stock_in"]
            col3_header = "Supplier" if blueprint.niche != "warehouse_stock_movement_tracker" else "Received From"
            demo = [("2026-01-03", "SKU001", f"DEMO: {col3_header}", 10, 4.25)]
            for i, row_vals in enumerate(demo, start=2):
                for col_idx, val in enumerate(row_vals, start=1):
                    if col_idx == 5 and blueprint.niche in (
                        "warehouse_stock_movement_tracker", "retail_store_inventory_tracker",
                    ):
                        continue  # these Stock In sheets have no unit-cost column
                    ws.cell(row=i, column=col_idx, value=val)

        if "stock_out" in sheets and blueprint.niche in (
            "small_business_inventory_tracker", "warehouse_stock_movement_tracker",
            "retail_store_inventory_tracker",
        ):
            ws = sheets["stock_out"]
            reason_val = "DEMO: Store A" if blueprint.niche == "warehouse_stock_movement_tracker" else "Sale"
            demo = [("2026-01-06", "SKU001", reason_val, 3)]
            for i, (date, sku, reason, qty) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=date)
                ws.cell(row=i, column=2, value=sku)
                ws.cell(row=i, column=3, value=reason)
                ws.cell(row=i, column=4, value=qty)

        if "inventory" in sheets and blueprint.niche == "retail_store_inventory_tracker":
            ws = sheets["inventory"]
            demo = [("SKU001", "DEMO: Cotton T-Shirt", "M", "Apparel", 5.00, 18.00, 30, 10)]
            for i, (sku, name, size, cat, cost, price, onhand, reorder) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=sku)
                ws.cell(row=i, column=2, value=name)
                ws.cell(row=i, column=3, value=size)
                ws.cell(row=i, column=4, value=cat)
                ws.cell(row=i, column=5, value=cost)
                ws.cell(row=i, column=6, value=price)
                ws.cell(row=i, column=7, value=onhand)
                ws.cell(row=i, column=8, value=reorder)

        if "ingredients" in sheets:
            ws = sheets["ingredients"]
            demo = [("DEMO: Whole Milk (L)", "L", 1.20, 8, 3, "2026-01-20")]
            for i, (item, unit, cost, onhand, reorder, expiry) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=item)
                ws.cell(row=i, column=2, value=unit)
                ws.cell(row=i, column=3, value=cost)
                ws.cell(row=i, column=4, value=onhand)
                ws.cell(row=i, column=5, value=reorder)
                ws.cell(row=i, column=6, value=expiry)

        if "usage_log" in sheets:
            ws = sheets["usage_log"]
            demo = [("2026-01-10", "DEMO: Whole Milk (L)", "DEMO: Latte", 2.0)]
            for i, (date, item, menu, qty) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=date)
                ws.cell(row=i, column=2, value=item)
                ws.cell(row=i, column=3, value=menu)
                ws.cell(row=i, column=4, value=qty)

        if "waste_log" in sheets:
            ws = sheets["waste_log"]
            demo = [("2026-01-11", "DEMO: Whole Milk (L)", "Spoiled", 0.5)]
            for i, (date, item, reason, qty) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=date)
                ws.cell(row=i, column=2, value=item)
                ws.cell(row=i, column=3, value=reason)
                ws.cell(row=i, column=4, value=qty)

        if "item_master" in sheets:
            ws = sheets["item_master"]
            demo = [("SKU001", "DEMO: Shipping Boxes", "Aisle 3", "ea", 120, 30)]
            for i, (sku, name, loc, unit, onhand, reorder) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=sku)
                ws.cell(row=i, column=2, value=name)
                ws.cell(row=i, column=3, value=loc)
                ws.cell(row=i, column=4, value=unit)
                ws.cell(row=i, column=5, value=onhand)
                ws.cell(row=i, column=6, value=reorder)

        if "transfers" in sheets:
            ws = sheets["transfers"]
            demo = [("2026-01-08", "SKU001", "DEMO: Warehouse A", "DEMO: Warehouse B", 15)]
            for i, (date, sku, frm, to, qty) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=date)
                ws.cell(row=i, column=2, value=sku)
                ws.cell(row=i, column=3, value=frm)
                ws.cell(row=i, column=4, value=to)
                ws.cell(row=i, column=5, value=qty)

        if "inventory" in sheets and blueprint.niche == "reseller_profit_inventory_tracker":
            ws = sheets["inventory"]
            demo = [("SKU001", "DEMO: Vintage Tee", "Etsy", 6.00, 22.00, 15)]
            for i, (sku, name, platform, cost, price, starting_qty) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=sku)
                ws.cell(row=i, column=2, value=name)
                ws.cell(row=i, column=3, value=platform)
                ws.cell(row=i, column=4, value=cost)
                ws.cell(row=i, column=5, value=price)
                ws.cell(row=i, column=6, value=starting_qty)

        if "sales_log" in sheets:
            ws = sheets["sales_log"]
            demo = [("2026-01-09", "SKU001", 22.00, 2.20, 4.50)]
            for i, (date, sku, sale_price, fees, ship) in enumerate(demo, start=2):
                ws.cell(row=i, column=1, value=date)
                ws.cell(row=i, column=2, value=sku)
                ws.cell(row=i, column=3, value=sale_price)
                ws.cell(row=i, column=4, value=fees)
                ws.cell(row=i, column=5, value=ship)

    def _apply_formulas(self, sheets: dict[str, Worksheet], blueprint: ProductBlueprint, spec: ProductSpec) -> None:
        """Wire up named ranges + cross-sheet formulas so the dashboard
        reflects live totals rather than baked-in numbers."""
        wb = next(iter(sheets.values())).parent

        if blueprint.niche == "monthly_budget_tracker":
            income_ws, expenses_ws, dash_ws = sheets["income"], sheets["expenses"], sheets["dashboard"]
            self._define_name(wb, "Income_Total", f"'{income_ws.title}'!$C$2:$C$50")
            self._define_name(wb, "Expenses_Total", f"'{expenses_ws.title}'!$D$2:$D$50")
            dash_ws["A1"] = "Total Income"
            dash_ws["B1"] = "=SUM(Income_Total)"
            dash_ws["B1"].number_format = "#,##0.00"
            dash_ws["A2"] = "Total Expenses"
            dash_ws["B2"] = "=SUM(Expenses_Total)"
            dash_ws["B2"].number_format = "#,##0.00"
            dash_ws["A3"] = "Remaining"
            dash_ws["B3"] = "=B1-B2"
            dash_ws["B3"].number_format = "#,##0.00"

        elif blueprint.niche == "freelancer_finance_tracker":
            income_ws = sheets["client_income"]
            exp_ws = sheets["business_expenses"]
            dash_ws = sheets["dashboard"]
            self._define_name(wb, "Gross_Income", f"'{income_ws.title}'!$D$2:$D$50")
            self._define_name(wb, "Business_Expenses_Total", f"'{exp_ws.title}'!$D$2:$D$50")
            dash_ws["A1"] = "Gross Income (YTD)"
            dash_ws["B1"] = "=SUM(Gross_Income)"
            dash_ws["A2"] = "Business Expenses (YTD)"
            dash_ws["B2"] = "=SUM(Business_Expenses_Total)"
            dash_ws["A3"] = "Net Income (YTD)"
            dash_ws["B3"] = "=B1-B2"
            for col in ("B1", "B2", "B3"):
                dash_ws[col].number_format = "#,##0.00"

            tax_ws = sheets["tax_setaside"]
            for row in range(2, 6):
                # Set-Aside Amount = Net Income * Tax Rate. Blank inputs
                # multiply to 0, which is harmless until the user fills them in.
                cell = tax_ws.cell(row=row, column=4, value=f"=B{row}*C{row}")
                cell.number_format = "#,##0.00"

            dash_ws["A4"] = "Outstanding Invoices"
            dash_ws["B4"] = f"=SUMIF('{income_ws.title}'!C2:C50,\"<>Paid\",'{income_ws.title}'!D2:D50)"
            dash_ws["B4"].number_format = "#,##0.00"

        elif blueprint.niche == "debt_payoff_tracker":
            debts_ws = sheets["debts"]
            payments_ws = sheets["payment_log"]
            dash_ws = sheets["dashboard"]
            # One dashboard row per debt (matched by name); simple MVP
            # approach — up to 10 debts.
            for i in range(2, 12):
                debt_name_cell = f"'{debts_ws.title}'!A{i}"
                dash_ws.cell(row=i, column=1, value=f"={debt_name_cell}")
                dash_ws.cell(row=i, column=2, value=f"='{debts_ws.title}'!C{i}")
                dash_ws.cell(row=i, column=2).number_format = "#,##0.00"
                remaining_formula = (
                    f"=MAX('{debts_ws.title}'!C{i}-SUMIF('{payments_ws.title}'!B:B,"
                    f"'{debts_ws.title}'!A{i},'{payments_ws.title}'!C:C),0)"
                )
                dash_ws.cell(row=i, column=3, value=remaining_formula)
                dash_ws.cell(row=i, column=3).number_format = "#,##0.00"
                progress_formula = (
                    f"=IF('{debts_ws.title}'!C{i}=0,0,1-(C{i}/'{debts_ws.title}'!C{i}))"
                )
                dash_ws.cell(row=i, column=4, value=progress_formula)
                dash_ws.cell(row=i, column=4).number_format = "0.0%"

        elif blueprint.niche == "small_business_inventory_tracker":
            inv_ws = sheets["inventory"]
            stock_in_ws = sheets["stock_in"]
            stock_out_ws = sheets["stock_out"]
            dash_ws = sheets["dashboard"]

            # Per-row: On Hand is a live perpetual balance from the stock
            # in/out logs (not a manually re-typed number), and Margin %
            # is computed from cost vs retail — both formulas, not values.
            for row in range(2, 52):
                sku_cell = f"A{row}"
                on_hand_formula = (
                    f"=SUMIF('{stock_in_ws.title}'!B:B,{sku_cell},'{stock_in_ws.title}'!D:D)"
                    f"-SUMIF('{stock_out_ws.title}'!B:B,{sku_cell},'{stock_out_ws.title}'!D:D)"
                )
                inv_ws.cell(row=row, column=6, value=on_hand_formula)
                margin_formula = f"=IF(E{row}=0,0,(E{row}-D{row})/E{row})"
                inv_ws.cell(row=row, column=8, value=margin_formula)
                inv_ws.cell(row=row, column=8).number_format = "0.0%"

            self._define_name(wb, "Inv_Value_Range", f"'{inv_ws.title}'!$D$2:$D$51")
            dash_ws["A1"] = "Total Inventory Value (at cost)"
            dash_ws["B1"] = f"=SUMPRODUCT('{inv_ws.title}'!D2:D51,'{inv_ws.title}'!F2:F51)"
            dash_ws["B1"].number_format = "#,##0.00"
            dash_ws["A2"] = "Items Below Reorder Point"
            dash_ws["B2"] = f"=SUMPRODUCT(('{inv_ws.title}'!F2:F51<='{inv_ws.title}'!G2:G51)*('{inv_ws.title}'!A2:A51<>\"\"))"
            dash_ws["A3"] = "Total Units on Hand"
            dash_ws["B3"] = f"=SUM('{inv_ws.title}'!F2:F51)"
            dash_ws["B3"].number_format = "#,##0"

        elif blueprint.niche == "warehouse_stock_movement_tracker":
            item_ws = sheets["item_master"]
            stock_in_ws = sheets["stock_in"]
            stock_out_ws = sheets["stock_out"]
            transfers_ws = sheets["transfers"]
            dash_ws = sheets["dashboard"]

            for row in range(2, 52):
                sku_cell = f"A{row}"
                # Total on-hand across all locations = stock in - stock out;
                # a location transfer moves stock between bins but doesn't
                # change the company-wide total, so it's excluded here.
                # The Location Transfers sheet is the audit trail for where
                # each unit currently sits.
                balance_formula = (
                    f"=SUMIF('{stock_in_ws.title}'!B:B,{sku_cell},'{stock_in_ws.title}'!D:D)"
                    f"-SUMIF('{stock_out_ws.title}'!B:B,{sku_cell},'{stock_out_ws.title}'!D:D)"
                )
                item_ws.cell(row=row, column=5, value=balance_formula)

            dash_ws["A1"] = "Items Below Reorder Point"
            dash_ws["B1"] = f"=SUMPRODUCT(('{item_ws.title}'!E2:E51<='{item_ws.title}'!F2:F51)*('{item_ws.title}'!A2:A51<>\"\"))"
            dash_ws["A2"] = "Total Units on Hand"
            dash_ws["B2"] = f"=SUM('{item_ws.title}'!E2:E51)"
            dash_ws["B2"].number_format = "#,##0"

        elif blueprint.niche == "reseller_profit_inventory_tracker":
            inv_ws = sheets["inventory"]
            sales_ws = sheets["sales_log"]
            dash_ws = sheets["dashboard"]

            for row in range(2, 52):
                sku_cell = f"A{row}"
                # On Hand = Starting Qty (col F, a plain input) minus units
                # matched off the sales log by SKU (COUNTIF, since each
                # sales-log row = one unit sold in this MVP). Written into
                # col G so it never references its own cell.
                on_hand_formula = f"=F{row}-COUNTIF('{sales_ws.title}'!B:B,{sku_cell})"
                inv_ws.cell(row=row, column=7, value=on_hand_formula)

            for row in range(2, 52):
                net_profit_formula = f"=C{row}-D{row}-E{row}"
                sales_ws.cell(row=row, column=6, value=net_profit_formula)
                sales_ws.cell(row=row, column=6).number_format = "#,##0.00"

            dash_ws["A1"] = "Total Revenue"
            dash_ws["B1"] = f"=SUM('{sales_ws.title}'!C2:C51)"
            dash_ws["A2"] = "Total Fees + Shipping Paid"
            dash_ws["B2"] = f"=SUM('{sales_ws.title}'!D2:D51)+SUM('{sales_ws.title}'!E2:E51)"
            dash_ws["A3"] = "Net Profit"
            dash_ws["B3"] = f"=SUM('{sales_ws.title}'!F2:F51)"
            for cell in ("B1", "B2", "B3"):
                dash_ws[cell].number_format = "#,##0.00"

        elif blueprint.niche == "retail_store_inventory_tracker":
            inv_ws = sheets["inventory"]
            stock_in_ws = sheets["stock_in"]
            stock_out_ws = sheets["stock_out"]
            dash_ws = sheets["dashboard"]

            for row in range(2, 52):
                sku_cell = f"A{row}"
                on_hand_formula = (
                    f"=SUMIF('{stock_in_ws.title}'!B:B,{sku_cell},'{stock_in_ws.title}'!D:D)"
                    f"-SUMIF('{stock_out_ws.title}'!B:B,{sku_cell},'{stock_out_ws.title}'!D:D)"
                )
                inv_ws.cell(row=row, column=7, value=on_hand_formula)
                margin_formula = f"=IF(F{row}=0,0,(F{row}-E{row})/F{row})"
                inv_ws.cell(row=row, column=9, value=margin_formula)
                inv_ws.cell(row=row, column=9).number_format = "0.0%"

            dash_ws["A1"] = "Total Inventory Value (at cost)"
            dash_ws["B1"] = f"=SUMPRODUCT('{inv_ws.title}'!E2:E51,'{inv_ws.title}'!G2:G51)"
            dash_ws["B1"].number_format = "#,##0.00"
            dash_ws["A2"] = "Items Below Reorder Point"
            dash_ws["B2"] = f"=SUMPRODUCT(('{inv_ws.title}'!G2:G51<='{inv_ws.title}'!H2:H51)*('{inv_ws.title}'!A2:A51<>\"\"))"
            dash_ws["A3"] = "Units Sold (Stock Out: Sale)"
            dash_ws["B3"] = f"=SUMIF('{stock_out_ws.title}'!C:C,\"Sale\",'{stock_out_ws.title}'!D:D)"
            dash_ws["B3"].number_format = "#,##0"

        elif blueprint.niche == "cafe_restaurant_inventory_tracker":
            ing_ws = sheets["ingredients"]
            waste_ws = sheets["waste_log"]
            dash_ws = sheets["dashboard"]

            self._define_name(wb, "Waste_Cost_Helper", f"'{waste_ws.title}'!$D$2:$D$50")
            dash_ws["A1"] = "Ingredients Below Reorder Point"
            dash_ws["B1"] = f"=SUMPRODUCT(('{ing_ws.title}'!D2:D51<='{ing_ws.title}'!E2:E51)*('{ing_ws.title}'!A2:A51<>\"\"))"
            dash_ws["A2"] = "Ingredients Expiring Within 7 Days"
            dash_ws["B2"] = (
                f"=SUMPRODUCT(('{ing_ws.title}'!F2:F51<>\"\")*"
                f"('{ing_ws.title}'!F2:F51<=TODAY()+7))"
            )
            dash_ws["A3"] = "Estimated Waste Cost (uses Ingredients unit cost x Waste Log qty)"
            dash_ws["B3"] = (
                f"=SUMPRODUCT(SUMIF('{ing_ws.title}'!A:A,'{waste_ws.title}'!B2:B50,'{ing_ws.title}'!C:C),"
                f"'{waste_ws.title}'!D2:D50)"
            )
            dash_ws["B3"].number_format = "#,##0.00"

    def _write_instructions(
        self, ws: Worksheet | None, product_spec: ProductSpec, blueprint: ProductBlueprint, style: "_StyleKit"
    ) -> None:
        if ws is None:
            return
        lines = [
            f"{blueprint.display_name} — How to use this workbook",
            "",
            f"Who this is for: {product_spec.target_customer or blueprint.default_target_customer}",
            "",
            "Getting started:",
            "1. Enter your own data in the input sheets (rows marked DEMO can be deleted).",
            "2. Totals and percentages update automatically — you do not need to edit formula cells.",
            "3. Use the dropdown lists provided in category/status columns for consistent data entry.",
            "",
            "This template is provided for personal budgeting organization only and does not",
            "constitute financial advice.",
        ]
        for i, line in enumerate(lines, start=1):
            cell = ws.cell(row=i, column=1, value=line)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.column_dimensions["A"].width = 90

    def _clear_demo_rows(self, sheets: dict[str, Worksheet], blueprint: ProductBlueprint) -> None:
        """Remove seeded demo values from data-entry cells so the shipped
        product starts empty for the buyer. Formula cells and headers are
        left untouched."""
        data_sheet_keys = {
            "income", "expenses", "client_income", "business_expenses",
            "tax_setaside", "debts", "payment_log",
            "inventory", "stock_in", "stock_out", "item_master", "transfers", "sales_log",
            "ingredients", "usage_log", "waste_log",
        }
        for key in data_sheet_keys & sheets.keys():
            ws = sheets[key]
            for row in ws.iter_rows(min_row=2, max_row=15):
                for cell in row:
                    if cell.value is not None and not (isinstance(cell.value, str) and cell.value.startswith("=")):
                        cell.value = None

    # ------------------------------------------------------------------
    # Integrity verification
    # ------------------------------------------------------------------

    def _verify_integrity(self, file_path: str, blueprint: ProductBlueprint) -> None:
        """Reopen the saved file and check it is well-formed: opens
        without error, has every expected sheet, and every sheet has a
        header row. This is a structural check, not a full formula
        evaluation (openpyxl does not evaluate formulas)."""
        from openpyxl import load_workbook

        try:
            wb = load_workbook(file_path, data_only=False)
        except Exception as e:
            raise XlsxIntegrityError(f"Workbook could not be reopened: {e}") from e

        expected_titles = {s.title[:31] for s in blueprint.sheets}
        actual_titles = set(wb.sheetnames)
        missing = expected_titles - actual_titles
        if missing:
            raise XlsxIntegrityError(f"Missing expected sheets: {missing}")

        for sheet_spec in blueprint.sheets:
            ws = wb[sheet_spec.title[:31]]
            header_values = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
            if not any(header_values):
                raise XlsxIntegrityError(f"Sheet '{sheet_spec.title}' has an empty header row")

    def _define_name(self, wb, name: str, ref: str) -> None:
        if name in wb.defined_names:
            del wb.defined_names[name]
        wb.defined_names[name] = DefinedName(name, attr_text=ref)


class _StyleKit:
    """Resolves a DesignProfile into concrete openpyxl style objects."""

    def __init__(self, design_profile: DesignProfile):
        typography = design_profile.typography or {}
        table_design = design_profile.table_design or {}
        spacing = design_profile.spacing or {}

        heading_font = typography.get("heading_font", "Calibri")
        header_fill_hex = table_design.get("header_fill", "1F2937")
        header_font_color = table_design.get("header_font_color", "FFFFFF")

        self.header_font = Font(name=heading_font, bold=True, color=header_font_color, size=11)
        self.header_fill = PatternFill(start_color=header_fill_hex, end_color=header_fill_hex, fill_type="solid")
        self.row_height = spacing.get("row_height", 18)
        thin = Side(style="thin", color="D1D5DB")
        self.thin_border = Border(left=thin, right=thin, top=thin, bottom=thin)
