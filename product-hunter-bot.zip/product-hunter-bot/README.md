# Product Hunter Bot

Free V1: Google Trends RSS -> product ideas -> opportunity score -> Telegram.

## GitHub Secrets

Add these repository secrets:

- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

No Etsy API key is required for this V1.

## Run

GitHub -> Actions -> Product Hunter -> Run workflow.

The workflow also runs daily at 08:00 UTC (11:00 Türkiye time in summer).
