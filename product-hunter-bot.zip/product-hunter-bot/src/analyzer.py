def calculate_score(item):
    score = 0
    trend = item["trend"].lower()

    if item["category"] in trend:
        score += 40
    else:
        score += 20

    commercial_words = [
        "template", "planner", "tracker",
        "printable", "canva", "notion"
    ]

    for word in commercial_words:
        if word in item["product"].lower():
            score += 10

    return min(score, 100)


def analyze(items):
    analyzed = []
    for item in items:
        result = item.copy()
        result["score"] = calculate_score(item)
        analyzed.append(result)

    analyzed.sort(key=lambda x: x["score"], reverse=True)
    return analyzed
