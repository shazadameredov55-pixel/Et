from trends import get_trending_topics
from product_finder import find_product_ideas
from analyzer import analyze
from telegram import send_message


def main():
    print("🚀 Product Hunter başladı")

    topics = get_trending_topics("TR")
    print(f"📈 Trend sayısı: {len(topics)}")

    ideas = find_product_ideas(topics)
    print(f"🛍️ Ürün adayları: {len(ideas)}")

    results = analyze(ideas)[:20]

    if not results:
        send_message(
            "🤖 PRODUCT HUNTER\n\n"
            "Bugün uygun ürün trendi bulunamadı."
        )
        return

    message = [
        "🤖 PRODUCT HUNTER",
        "",
        "🔥 BUGÜNÜN ÜRÜN FIRSATLARI",
        "",
    ]

    for index, item in enumerate(results, start=1):
        message.extend([
            f"{index}. {item['product']}",
            f"🎯 Score: {item['score']}/100",
            f"📈 Trend: {item['trend']}",
            f"🏷️ Kategori: {item['category']}",
        ])
        if item["trend_url"]:
            message.append(f"🔗 {item['trend_url']}")
        message.append("")

    # Telegram mesajlarını güvenli boyutta parçalara ayır.
    text = "\n".join(message)
    chunks = []
    while len(text) > 3800:
        cut = text.rfind("\n", 0, 3800)
        if cut <= 0:
            cut = 3800
        chunks.append(text[:cut])
        text = text[cut:].lstrip("\n")
    if text:
        chunks.append(text)

    for chunk in chunks:
        send_message(chunk)

    print("✅ Telegram raporu gönderildi.")


if __name__ == "__main__":
    main()
