PRODUCT_KEYWORDS = {
    "planner": ["digital planner", "printable planner", "planner template"],
    "budget": ["budget planner", "budget tracker", "expense tracker"],
    "wedding": ["wedding template", "wedding planner", "wedding invitation"],
    "fitness": ["fitness tracker", "workout planner", "fitness planner"],
    "social media": ["social media template", "instagram template", "content planner"],
    "resume": ["resume template", "cv template", "canva resume"],
    "notion": ["notion template", "notion planner", "notion tracker"],
    "canva": ["canva template", "editable canva template", "canva digital product"],
}


def find_product_ideas(topics):
    results = []
    for topic in topics:
        title = topic["title"].lower()
        for category, products in PRODUCT_KEYWORDS.items():
            if category in title:
                for product in products:
                    results.append({
                        "trend": topic["title"],
                        "category": category,
                        "product": product,
                        "trend_url": topic["url"],
                    })
    return results
