import feedparser


def get_trending_topics(country="TR"):
    url = f"https://trends.google.com/trending/rss?geo={country}"
    feed = feedparser.parse(url)

    topics = []
    for entry in feed.entries:
        title = entry.get("title", "").strip()
        if not title:
            continue
        topics.append({
            "title": title,
            "url": entry.get("link", ""),
            "published": entry.get("published", ""),
        })
    return topics
